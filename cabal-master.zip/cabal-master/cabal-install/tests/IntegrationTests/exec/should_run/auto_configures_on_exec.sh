. ../common.sh
cabal exec echo find_me_in_output
