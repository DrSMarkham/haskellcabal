. ../common.sh

cabal exec
