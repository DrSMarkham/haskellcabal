import Distribution.Simple
import System.IO
main = hPutStrLn stderr "Custom" >> defaultMain
