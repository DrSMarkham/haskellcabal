. ../common.sh
cd plain
cabal configure
cabal build
