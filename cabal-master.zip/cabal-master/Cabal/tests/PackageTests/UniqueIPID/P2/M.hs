module M(m) where

m = print "2"
