module Main where

import Foo

main :: IO ()
main = do
  let x = incr 4
  return ()
