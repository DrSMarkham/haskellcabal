import UnavailableModule

main :: IO ()
main = putStrLn "Hello"
